function addTask() {

    // Get input value
    const taskText = taskInput.value.trim();

    // Prevent empty task
    if (taskText === "") {
        alert("Please enter a task!");
        return;
    }

    // Create li
    const li = document.createElement("li");

    // Create span
    const span = document.createElement("span");
    span.textContent = taskText;

    // Create delete button
    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Delete";
    deleteBtn.classList.add("delete-btn");

    // Delete task
    deleteBtn.addEventListener("click", function () {
        li.remove();
    });

    // Add span and button to li
    li.appendChild(span);
    li.appendChild(deleteBtn);

    // Add li to ul
    taskList.appendChild(li);

    // Clear input
    taskInput.value = "";
}